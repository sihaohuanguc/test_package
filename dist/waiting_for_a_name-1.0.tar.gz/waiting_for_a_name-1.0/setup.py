from distutils.core import setup
setup(
    name="waiting_for_a_name",
    version="1.0",
    description="Just for fun",
    author="Me",
    py_modules=["codes.one","codes.two"]
)