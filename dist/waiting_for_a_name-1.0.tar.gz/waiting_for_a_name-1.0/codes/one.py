import os 
import sys

def once():
    print("Hello!")